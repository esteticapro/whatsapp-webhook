const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const qrcodeTerminal = require("qrcode-terminal");
const { Client, LocalAuth } = require("whatsapp-web.js");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));

// Map to hold clients by sessionId
const clients = {};

// Create or retrieve a client for a sessionId
function createClient(sessionId) {
  if (clients[sessionId]) return clients[sessionId];

  const client = new Client({
    authStrategy: new LocalAuth({ clientId: sessionId }),
    puppeteer: {
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas",
        "--no-first-run",
        "--no-zygote",
        "--single-process"
      ],
    },
  });

  client.sessionId = sessionId;
  client.isReady = false;

  client.on("qr", (qr) => {
    console.log(`QR gerado para sessão ${sessionId}`);
    qrcodeTerminal.generate(qr, { small: true });
    // emit via socket.io so frontend can show if connected
    io.emit("qr", { sessionId, qr });
  });

  client.on("ready", () => {
    console.log(`✅ Sessão ${sessionId} pronta`);
    client.isReady = true;
    io.emit("ready", { sessionId });
  });

  client.on("authenticated", () => {
    console.log(`🔐 Sessão ${sessionId} autenticada`);
    io.emit("authenticated", { sessionId });
  });

  client.on("auth_failure", (msg) => {
    console.log(`❌ Falha auth sessão ${sessionId}:`, msg);
    io.emit("auth_failure", { sessionId, msg });
  });

  client.on("disconnected", (reason) => {
    console.log(`⚠️ Sessão ${sessionId} desconectada:`, reason);
    client.isReady = false;
    io.emit("disconnected", { sessionId, reason });
    // remove client to allow recreate
    try {
      client.destroy();
    } catch (e) {}
    delete clients[sessionId];
  });

  client.on("message", (msg) => {
    console.log(`📩 Mensagem recebida [${sessionId}] from ${msg.from}: ${msg.body}`);
    io.emit("message", { sessionId, from: msg.from, body: msg.body });
  });

  client.initialize();
  clients[sessionId] = client;
  return client;
}

// Endpoint to create/start a session
app.post("/create-session", async (req, res) => {
  try {
    const { sessionId } = req.body;
    if (!sessionId) return res.status(400).json({ error: "sessionId é obrigatório" });

    createClient(sessionId);
    return res.json({ status: "starting", sessionId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Erro ao criar sessão" });
  }
});

// Endpoint to get status for a session
app.get("/session-status/:sessionId", (req, res) => {
  const { sessionId } = req.params;
  const client = clients[sessionId];
  if (!client) return res.json({ exists: false, ready: false });
  return res.json({ exists: true, ready: !!client.isReady });
});

// Endpoint to send a message
app.post("/send-message", async (req, res) => {
  try {
    const { sessionId, to, message } = req.body;
    if (!sessionId || !to || !message) return res.status(400).json({ error: "sessionId, to e message são obrigatórios" });

    const client = clients[sessionId];
    if (!client) return res.status(400).json({ error: "Sessão não iniciada. Chame /create-session primeiro." });
    if (!client.isReady) return res.status(400).json({ error: "Sessão ainda não está pronta." });

    await client.sendMessage(to, message);
    return res.json({ status: "sent" });
  } catch (err) {
    console.error("Erro ao enviar mensagem:", err);
    return res.status(500).json({ error: "Erro ao enviar mensagem" });
  }
});

// Basic index route (serves public/index.html)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

// Socket.io connection (optional, used to push QR and events)
io.on("connection", (socket) => {
  console.log("Socket conectado:", socket.id);
  socket.on("disconnect", () => console.log("Socket desconectado:", socket.id));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 Servidor rodando na porta ${PORT}`));
