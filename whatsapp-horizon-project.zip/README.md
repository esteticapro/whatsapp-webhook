# WhatsApp Horizon - Sessões por ID

Este projeto permite criar sessões do WhatsApp identificadas por `sessionId`. Ideal para Hostinger Horizon: você cria a sessão uma vez (escaneando o QR no console do servidor) e, em seguida, a sessão fica persistida no diretório `.wwebjs_auth`, evitando a necessidade de escanear o QR várias vezes.

## Estrutura do projeto
```
project-root/
 ├── src/
 │   └── server.js
 ├── public/
 │   └── index.html
 ├── package.json
 └── README.md
```

## Como usar (localmente)
1. `npm install`
2. `npm start`
3. Abra `http://localhost:3000` e use a interface para criar uma sessão (insira `sessionId` e clique em "Conectar WhatsApp").
4. Veja o QR Code no console (terminal) na primeira conexão. Escaneie com o WhatsApp do celular.

## Endpoints principais
- `POST /create-session` — Body: `{ "sessionId": "empresa123" }`
- `GET /session-status/:sessionId` — Retorna `{ exists, ready }`
- `POST /send-message` — Body: `{ "sessionId", "to", "message" }`

## Observações para Hostinger Horizon / Render
- O Horizon tende a preservar arquivos locais; o `.wwebjs_auth` deve persistir entre reinícios/deploys. Se seu ambiente limpar arquivos, pense em armazenar a pasta de sessão em um storage (S3, Supabase, etc).
- Verifique os logs do Horizon para visualizar o QR code (qrcode-terminal imprime QR no console).
- Garanta Node >= 18.

## Segurança
Não exponha seus arquivos de sessão publicamente. Proteja endpoints em produção (autenticação, tokens, etc.).

## Autor
Alisson Bastos Amorim
